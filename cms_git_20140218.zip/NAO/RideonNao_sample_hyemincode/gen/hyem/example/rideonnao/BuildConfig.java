/** Automatically generated file. DO NOT MODIFY */
package hyem.example.rideonnao;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}